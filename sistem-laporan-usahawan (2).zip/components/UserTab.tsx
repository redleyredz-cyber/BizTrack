
import React, { useState } from 'react';
import { Report, Category } from '../types';
import { MONTHS, YEARS, CATEGORIES } from '../constants.tsx';
import Countdown from './Countdown';
import { Loader2, Send, History, FileText, ChevronRight, DollarSign, UploadCloud } from 'lucide-react';

interface UserTabProps {
  currentUser: string;
  allReports: Report[];
  onAddReport: (report: Report) => void;
}

const UserTab: React.FC<UserTabProps> = ({ currentUser, allReports, onAddReport }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    month: MONTHS[new Date().getMonth()],
    year: new Date().getFullYear().toString(),
    category: 'Usahawan' as Category,
    entrepreneurName: '',
    debit: 0,
    credit: 0
  });

  const [file, setFile] = useState<File | null>(null);

  const netIncome = formData.debit - formData.credit;
  const userHistory = allReports.filter(r => r.pppkName === currentUser);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.entrepreneurName) return;

    setIsSubmitting(true);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newReport: Report = {
      id: crypto.randomUUID(),
      ...formData,
      pppkName: currentUser,
      netIncome,
      submittedAt: new Date().toISOString(),
      documentUrl: file ? URL.createObjectURL(file) : undefined
    };

    onAddReport(newReport);
    setIsSubmitting(false);
    
    // Reset form partially
    setFormData(prev => ({
      ...prev,
      entrepreneurName: '',
      debit: 0,
      credit: 0
    }));
    setFile(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Countdown />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Submission Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <h2 className="text-lg font-bold text-gray-900">Borang Laporan Bulanan</h2>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Bulan Laporan</label>
                  <select 
                    value={formData.month}
                    onChange={e => setFormData(p => ({ ...p, month: e.target.value }))}
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Tahun Laporan</label>
                  <select 
                    value={formData.year}
                    onChange={e => setFormData(p => ({ ...p, year: e.target.value }))}
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Kategori Usahawan</label>
                  <select 
                    value={formData.category}
                    onChange={e => setFormData(p => ({ ...p, category: e.target.value as Category }))}
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Usahawan</label>
                  <input 
                    type="text"
                    placeholder="Contoh: Ali Bin Abu"
                    required
                    value={formData.entrepreneurName}
                    onChange={e => setFormData(p => ({ ...p, entrepreneurName: e.target.value }))}
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Debit (RM)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-medium">RM</span>
                    <input 
                      type="number"
                      step="0.01"
                      value={formData.debit || ''}
                      onChange={e => setFormData(p => ({ ...p, debit: parseFloat(e.target.value) || 0 }))}
                      className="w-full p-2.5 pl-10 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Kredit (RM)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-medium">RM</span>
                    <input 
                      type="number"
                      step="0.01"
                      value={formData.credit || ''}
                      onChange={e => setFormData(p => ({ ...p, credit: parseFloat(e.target.value) || 0 }))}
                      className="w-full p-2.5 pl-10 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Pendapatan Bersih (RM)</label>
                  <div className={`p-2.5 rounded-lg border font-bold text-lg flex items-center justify-center ${netIncome >= 0 ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                    RM {netIncome.toFixed(2)}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Upload Dokumen (JPEG/JPG/PNG)</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-xl p-8 hover:bg-gray-50 transition-colors group">
                  <input 
                    type="file" 
                    accept=".jpeg,.jpg,.png"
                    onChange={e => setFile(e.target.files?.[0] || null)}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <div className="p-3 bg-blue-50 rounded-full group-hover:scale-110 transition-transform">
                      <UploadCloud className="w-8 h-8 text-blue-600" />
                    </div>
                    <div className="text-sm font-medium text-gray-600">
                      {file ? <span className="text-blue-600 font-bold">{file.name}</span> : 'Klik atau tarik fail ke sini'}
                    </div>
                    <p className="text-xs text-gray-400">Pastikan fail dalam format imej yang disokong</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button 
                  disabled={isSubmitting}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-bold py-3 px-10 rounded-xl shadow-lg shadow-blue-200 flex items-center gap-2 transition-all active:scale-95"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Menghantar...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" /> Hantar Laporan
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* User Summary Sidebar */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-gray-600" />
                <h2 className="text-lg font-bold text-gray-900">Ringkasan Laporan</h2>
              </div>
              <span className="bg-gray-100 text-gray-600 text-xs font-bold px-2 py-1 rounded-full">{userHistory.length} Total</span>
            </div>
            <div className="p-0 max-h-[600px] overflow-y-auto">
              {userHistory.length === 0 ? (
                <div className="p-8 text-center text-gray-400">
                  <p>Tiada laporan dihantar lagi</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {userHistory.map(report => (
                    <div key={report.id} className="p-4 hover:bg-gray-50 transition-colors group">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-bold text-gray-900 leading-tight">{report.entrepreneurName}</p>
                          <p className="text-xs text-gray-500 mt-1">{report.month} {report.year} &bull; {report.category}</p>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${report.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            RM {report.netIncome.toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-3">
                         <div className="flex gap-2">
                           <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-bold rounded uppercase">
                             Debit: {report.debit}
                           </span>
                           <span className="px-2 py-0.5 bg-red-50 text-red-600 text-[10px] font-bold rounded uppercase">
                             Kredit: {report.credit}
                           </span>
                         </div>
                         <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="bg-blue-600 rounded-2xl p-6 text-white shadow-xl shadow-blue-100">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5" /> Analisa Peribadi
            </h3>
            <div className="space-y-4">
              <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm">
                <p className="text-sm opacity-80 mb-1">Jumlah Pendapatan Bersih</p>
                <p className="text-2xl font-black">
                  RM {userHistory.reduce((acc, curr) => acc + curr.netIncome, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/10 p-3 rounded-xl backdrop-blur-sm">
                  <p className="text-[10px] uppercase opacity-80 mb-0.5">Laporan Selesai</p>
                  <p className="text-xl font-bold">{userHistory.length}</p>
                </div>
                <div className="bg-white/10 p-3 rounded-xl backdrop-blur-sm">
                  <p className="text-[10px] uppercase opacity-80 mb-0.5">Bulan Aktif</p>
                  <p className="text-xl font-bold">{new Set(userHistory.map(r => r.month)).size}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserTab;
