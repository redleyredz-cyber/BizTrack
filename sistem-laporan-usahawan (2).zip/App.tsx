
import React, { useState, useEffect } from 'react';
import { UserSession, Report } from './types';
import { USER_REGISTRY, ADMIN_REGISTRY, PPPK_NAMES, ADMIN_NAMES } from './constants';
import UserTab from './components/UserTab';
import AdminTab from './components/AdminTab';
import { ReportService } from './services/api';
import { 
  LayoutDashboard, 
  UserCircle, 
  LogOut, 
  ShieldCheck, 
  Lock, 
  AlertCircle,
  RefreshCw,
  WifiOff,
  CloudCheck,
  Clock
} from 'lucide-react';

const App: React.FC = () => {
  const [session, setSession] = useState<UserSession | null>(() => {
    const saved = localStorage.getItem('pppk_session');
    return saved ? JSON.parse(saved) : null;
  });

  const [reports, setReports] = useState<Report[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncError, setIsSyncError] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [roleSelection, setRoleSelection] = useState<'USER' | 'ADMIN'>('USER');

  const loadData = async () => {
    setIsLoading(true);
    setIsSyncError(false);
    try {
      const result = await ReportService.fetchReports();
      setReports(result.reports);
      setIsSyncError(!result.isLive);
      
      if (result.isLive) {
        setLastSync(new Date().toLocaleTimeString());
        localStorage.setItem('pppk_reports', JSON.stringify(result.reports));
      }
    } catch (err) {
      setIsSyncError(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (session) {
      loadData();
    }
  }, [session]);

  useEffect(() => {
    if (session) {
      localStorage.setItem('pppk_session', JSON.stringify(session));
    } else {
      localStorage.removeItem('pppk_session');
    }
  }, [session]);

  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginError(null);
    
    const formData = new FormData(e.currentTarget);
    const role = formData.get('role') as 'USER' | 'ADMIN';
    const name = formData.get('name') as string;
    const password = formData.get('password') as string;

    if (!name || !password) {
      setLoginError("Sila pilih nama dan masukkan kata laluan.");
      return;
    }

    const registry = role === 'ADMIN' ? ADMIN_REGISTRY : USER_REGISTRY;
    const correctPassword = registry[name];

    if (correctPassword === password) {
      setSession({ role, pppkName: name });
    } else {
      setLoginError(role === 'ADMIN' ? "Kata laluan tidak sah." : "No. IC tidak sah untuk nama yang dipilih.");
    }
  };

  const handleLogout = () => {
    setSession(null);
  };

  const handleAddReport = async (report: Report) => {
    setReports(prev => [report, ...prev]);
    const success = await ReportService.addReport(report);
    if (!success) {
      setIsSyncError(true);
    } else {
      setLastSync(new Date().toLocaleTimeString());
    }
  };

  const handleDeleteReport = (id: string) => {
    const updated = reports.filter(r => r.id !== id);
    setReports(updated);
    localStorage.setItem('pppk_reports', JSON.stringify(updated));
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-gray-100">
          <div className="flex flex-col items-center mb-8">
            <div className="p-4 bg-blue-50 rounded-full mb-4">
              <LayoutDashboard className="w-12 h-12 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Sistem Laporan Usahawan</h1>
            <p className="text-gray-500 text-center mt-2">Sila log masuk untuk meneruskan</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Peranan</label>
              <select 
                name="role" 
                value={roleSelection}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-gray-50"
                onChange={(e) => {
                  setRoleSelection(e.target.value as 'USER' | 'ADMIN');
                  setLoginError(null);
                }}
              >
                <option value="USER">Pengguna (PPPK)</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nama {roleSelection === 'ADMIN' ? 'Admin' : 'PPPK'}</label>
              <select 
                name="name" 
                required
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-gray-50"
              >
                <option value="">Pilih Nama</option>
                {(roleSelection === 'ADMIN' ? ADMIN_NAMES : PPPK_NAMES).map(name => (
                  <option key={name} value={name}>{name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {roleSelection === 'ADMIN' ? 'Kata Laluan' : 'Kata Laluan (No. IC)'}
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="password"
                  name="password"
                  required
                  placeholder={roleSelection === 'ADMIN' ? "Masukkan kata laluan" : "Contoh: 86052713XXXX"}
                  className="w-full p-3 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-gray-50"
                />
              </div>
            </div>

            {loginError && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-lg animate-pulse">
                <AlertCircle className="w-4 h-4" />
                {loginError}
              </div>
            )}

            <button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold p-3 rounded-lg shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Log Masuk
            </button>
          </form>
          
          <p className="mt-8 text-center text-xs text-gray-400">
            &copy; {new Date().getFullYear()} Sistem Pengurusan Laporan Usahawan
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col relative">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-600 rounded-lg">
                <LayoutDashboard className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-gray-900 leading-none hidden sm:block">Laporan Usahawan</span>
                <div className="flex items-center gap-2 mt-1">
                  <div className={`w-2 h-2 rounded-full ${isLoading ? 'bg-blue-400 animate-ping' : (isSyncError ? 'bg-red-500' : 'bg-green-500')}`}></div>
                  <span className={`text-[9px] font-bold uppercase tracking-wider ${isSyncError ? 'text-red-500' : 'text-gray-400'}`}>
                    {isLoading ? 'Syncing...' : (isSyncError ? 'Mode Offline' : 'GSheet Live')}
                  </span>
                  {lastSync && !isSyncError && (
                    <span className="text-[9px] text-gray-300 flex items-center gap-1 border-l pl-2 border-gray-100">
                      <Clock className="w-2.5 h-2.5" /> {lastSync}
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 md:gap-4">
              <div className="hidden sm:flex items-center gap-2 text-sm">
                {session.role === 'ADMIN' ? (
                  <div className="flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-1.5 rounded-full font-bold border border-amber-200 shadow-sm">
                    <ShieldCheck className="w-4 h-4" /> <span className="hidden md:inline">{session.pppkName}</span> (Admin)
                  </div>
                ) : (
                  <div className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full font-bold border border-blue-200 shadow-sm">
                    <UserCircle className="w-4 h-4" /> <span className="hidden md:inline">{session.pppkName}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-1">
                <button 
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  title="Log Keluar"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        {isSyncError && reports.length > 0 && (
          <div className="bg-red-50 border-b border-red-100 px-4 py-2 flex items-center justify-center gap-2 text-red-600 text-xs font-bold no-print animate-pulse">
            <WifiOff className="w-3 h-3" /> 
            Gagal Sync dengan Cloud. Anda melihat data lama.
            <button onClick={loadData} className="ml-2 underline hover:text-red-800">Cuba Lagi</button>
          </div>
        )}
        
        {isLoading && reports.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24">
            <div className="relative">
              <RefreshCw className="w-12 h-12 text-blue-600 animate-spin" />
              <CloudCheck className="w-6 h-6 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            </div>
            <p className="mt-4 text-gray-500 font-bold animate-pulse">Menghubungkan ke Google Sheets...</p>
          </div>
        ) : (
          session.role === 'ADMIN' ? (
            <AdminTab reports={reports} onDeleteReport={handleDeleteReport} onRefresh={loadData} isRefreshing={isLoading} />
          ) : (
            <UserTab 
              currentUser={session.pppkName!} 
              allReports={reports} 
              onAddReport={handleAddReport} 
            />
          )
        )}
      </main>
    </div>
  );
};

export default App;
